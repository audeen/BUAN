<?php

//////////////////////////////////////////////////
//  BUAN-Projekt                                //
//  Dateiname    : dashboard.php                //
//  Fachbereich Medien FH-Kiel - 5. Semester    //
//  Beschreibung : Startseite Backend           //
//  Ersteller    : Jannik Sievert               //
//  Stand        : 07.10.2019                   //
//  Version      : 1.0                          //
//////////////////////////////////////////////////

echo "Hallo Welt!";
?>