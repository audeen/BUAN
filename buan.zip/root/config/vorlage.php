<?php

//////////////////////////////////////////////////
//  BUAN-Projekt                                //
//  Dateiname:                                  //
//  Fachbereich Medien FH-Kiel - 5. Semester    //
//  Beschreibung :                       //
//  Ersteller    : Jannik Sievert               //
//  Stand        :                              //
//  Version      : 1.0                          //
//////////////////////////////////////////////////


?>