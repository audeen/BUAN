<?php

///////////////////////////////////////////////////////////
//  Variablen fuer Kontrolle - var_control.php           //
//  Fachbereich Medien FH-Kiel - 4.Semester              //
//  Beschreibung    : Variablen-Array                    //
//  Ersteller       : Johannes Rebitz                    //
//  Stand           : 29.03.2019                         //
//  Version         : 1.0                                //
///////////////////////////////////////////////////////////

// In den Ordner kopieren, wo php Seiten liegen und dann mit Inhalt fuellen
// Hier Variabelen eintragen fuer Control
$var_control[1][1] = "";
$var_control[1][2] = "";
$var_control[2][1] = "";
$var_control[2][2] = "";
$var_control[3][1] = "";
$var_control[3][2] = "";
$var_control[4][1] = "";
$var_control[4][2] = "";
$var_control[5][1] = "";
$var_control[5][2] = "";
$var_control[6][1] = "";
$var_control[6][2] = "";
$var_control[7][1] = "";
$var_control[7][2] = "";
$var_control[8][1] = "";
$var_control[8][2] = "";
$var_control[9][1] = "";
$var_control[9][2] = "";
$var_control[10][1] = "";
$var_control[10][2] = "";

?>